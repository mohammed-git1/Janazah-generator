function generateMessage() {
  const get = id => document.getElementById(id).value.trim();
  const msg = 
`🕊️ *Janazah Salaah Announcement*

The Janazah Salaah of *${get('name')}*
(${get('relation')})
will be held:

📍 *${get('masjid')}*
📌 ${get('masjidAddress')}
📅 *${get('date')}*
🕐 *Zuhr at ${get('zuhrTime')}*
🔹 *Janazah will be after Zuhr at ${get('janazahTime')}*
⚰️ *Burial at ${get('cemetery')} at ${get('burialTime')}*

📿 Condolences will be accepted
📍 *${get('condolenceLocation')}*
🕓 *${get('condolenceTime')}*
Concludes with *Esha Prayer*

🤲 Please remember the deceased and their family in your duaas.`;
  
  const phone = get('whatsappNumber').replace(/\D/g,'');
  const link = `https://wa.me/${phone}?text=` + encodeURIComponent(msg);
  window.open(link, '_blank');
}
